# BuildA — Building Construction Blaster

A self-contained, responsive educational game for beginner Diploma in Interior Design students. It teaches basic concepts in floor, wall, ceiling, and roof construction through a moving-target quiz.

## Run locally
Open `index.html` in a modern browser. No build tools, dependencies, server, or API keys are required.

## Publish with GitHub Pages
1. Create a GitHub repository (for example, `builda-learning-game`).
2. Upload `index.html` and `README.md` to the repository root.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select the `main` branch and `/(root)`, then click **Save**.
6. Wait for GitHub Pages to publish the site; use the URL shown in the Pages settings.

## Gameplay
- Click **Play BuildA**.
- Read the question and shoot an answer by clicking/tapping its moving target.
- Correct answers earn points, add energy, and tag a rival bot. Wrong answers cost points and energy.
- Choose Easy, Medium, or Hard to change target speed and scoring.
- Finish 10 questions within five minutes. A round can be restarted at any time.

## Teaching note
Questions cover introductory concepts only. Construction methods, terminology, and material suitability vary by location and project; use this game as a starter activity alongside your course notes and local building standards.
